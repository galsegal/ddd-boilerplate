﻿using System;

namespace $safeprojectname$
{
    public class Bootstrap
    {
        public void Init()
        {
           
        }
    }
}
